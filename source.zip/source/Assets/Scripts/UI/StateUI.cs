using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StateUI : MonoBehaviour {
    [SerializeField] private GlobalContext _context;
    [SerializeField] private TextMeshProUGUI _colorToAvoid;
    [SerializeField] private TextMeshProUGUI _timeToColorChange;
    [SerializeField] private TextMeshProUGUI _scoreLabel;
    [SerializeField] private TextMeshProUGUI _score;
    [SerializeField] private TextMeshProUGUI _scoreMultiplier;
    [SerializeField] private GameObject _gameOverScreen;
    [SerializeField] private TextMeshProUGUI _finalScore;
    [SerializeField] private TextMeshProUGUI _bestScore;

    private void Awake() {
        _gameOverScreen.SetActive(false);
        _score.gameObject.SetActive(true);
        _scoreLabel.gameObject.SetActive(true);
    }

    void OnEnable() {
        _context.State.OnTileTypeChanged += OnTileTypeChanged;
        _context.State.OnGameOver += OnGameOver;
    }

    private void OnDisable() {
        _context.State.OnTileTypeChanged -= OnTileTypeChanged;
        _context.State.OnGameOver -= OnGameOver;
    }

    private void OnGameOver() {
        _gameOverScreen.SetActive(true);
        _score.gameObject.SetActive(false);
        _scoreLabel.gameObject.SetActive(false);
        _finalScore.text = ((int) _context.State.Score.Value).ToString();
        _bestScore.text = ((int) _context.State.BestScore).ToString();
    }

    private void OnTileTypeChanged() {
//        Debug.Log($"Avaoided Tile type changed to {_context.State.CurrentTileToAvoid}");
        switch (_context.State.CurrentTileToAvoid) {
            case TrackTile.TileType.Tile1:
                _colorToAvoid.text = "GREEN";
                _colorToAvoid.color = Color.green;
                break;
            case TrackTile.TileType.Tile2:
                _colorToAvoid.text = "RED";
                _colorToAvoid.color = Color.red;
                break;
        }
    }

    // Update is called once per frame
    void Update() {
        _timeToColorChange.text = ((int) _context.State.TimeLeftToChangeTile.Value + 1).ToString();
        _score.text = ((int) _context.State.Score.Value).ToString();
        _scoreMultiplier.text = $"x{((int) _context.State.ScoreMultiplier.Value).ToString()}";

        if (Input.GetKeyDown(KeyCode.Return) && _context.State.IsGameOver) {
            RestartGame();
        }
        
        if (Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.R)) {
            PlayerPrefs.DeleteAll();
            PlayerPrefs.Save();
        }
    }

    private void RestartGame() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }
}