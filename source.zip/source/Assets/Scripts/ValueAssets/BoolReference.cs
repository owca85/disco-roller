﻿using System;

[Serializable]
public class BoolReference : ValueReference<bool, BoolAsset> {
}