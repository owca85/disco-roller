﻿using UnityEngine;

public abstract class ValueReference<TValue, TAsset> where TAsset : ValueAsset<TValue> {
    [SerializeField] protected bool _useValue;
    [SerializeField] protected TValue _value;
    [SerializeField] protected TAsset _asset;

    public TValue Value => _useValue || _asset == null ? _value : _asset.Value;

    public void Set(TValue value) {
        if (_useValue || _asset == null) {
            _value = value;
        }
        else {
            _asset.Value = value;
        }
    }

    public static implicit operator TValue(ValueReference<TValue, TAsset> valueRef) {
        return valueRef.Value;
    }
}