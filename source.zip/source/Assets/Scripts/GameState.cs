﻿using System;
using UnityEngine;
using UnityEngine.PlayerLoop;

[CreateAssetMenu(menuName = "LD51/GameState")]
public class GameState : ScriptableObject {
    public bool IsGamePaused;
    public bool IsGameOver;
    public bool IsPlayerDead;
    public FloatReference Score;
    public FloatReference SoundVolume;
    public FloatReference GameSpeed;

    public float BestScore;

    public TrackTile.TileType CurrentTileToAvoid;
    public TrackTile.TileType NextTileToAvoid;
    public FloatReference TimeLeftToChangeTile;
    public FloatReference ScoreMultiplier;

    public event Action OnGameOver;
    public event Action OnRowDestroyed;
    
    public event Action OnTileTypeChanged;

    public void Reset() {
        IsGamePaused = false;
        IsGameOver = false;
        IsPlayerDead = false;
        Score.Set(0);
        ScoreMultiplier.Set(0);
        TimeLeftToChangeTile.Set(10);
        UnpauseGame();
        RestoreSoundVolume();
//        GameSpeed.Set(1);
    }

    private void RestoreSoundVolume() {
        var volume = PlayerPrefs.HasKey("soundVolume") ? PlayerPrefs.GetFloat("soundVolume") : 1;
        SoundVolume.Set(volume);
    }

    public void PlayerDead() {
        Debug.Log($"PlayerDead");

        if (PlayerPrefs.HasKey("BestScore")) {
            BestScore = PlayerPrefs.GetFloat("BestScore");
        }

        if (Score.Value > BestScore) {
            BestScore = Score.Value;
            PlayerPrefs.SetFloat("BestScore", BestScore);
            PlayerPrefs.Save();
        }
        
        if (!IsGameOver) {
            OnGameOver?.Invoke();
            IsGameOver = true;
            MuteSounds();
        }
    }

    private void MuteSounds() {
        SoundVolume.Set(0.001f);
    }

    public bool IsInputDisabled => IsGamePaused || IsGameOver || IsPlayerDead;

    public void PauseGame() {
        IsGamePaused = true;
        Time.timeScale = 0;
    }

    public void UnpauseGame() {
        IsGamePaused = false;
        Time.timeScale = 1;
    }

    public void ToggleGamePause() {
        if (IsGamePaused) {
            UnpauseGame();
        }
        else {
            PauseGame();
        }
    }

    public void ChangeTileToAvoid() {
//        CurrentTileToAvoid = NextTileToAvoid;
//        NextTileToAvoid = CurrentTileToAvoid == TrackTile.TileType.Tile1 //TODO find better way
//            ? TrackTile.TileType.Tile2
//            : TrackTile.TileType.Tile1;
        OnTileTypeChanged?.Invoke();
        ScoreMultiplier.Set(ScoreMultiplier + 1);
    }

    public void AddScore(float amount) {
        Score.Set(Score + amount * ScoreMultiplier * 10);
    }

    public void RowDestroyed() {
        OnRowDestroyed?.Invoke();
    }
}