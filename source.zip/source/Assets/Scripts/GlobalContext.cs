﻿using UnityEngine;

[CreateAssetMenu(menuName = "LD51/GlobalContext")]
public class GlobalContext : ScriptableObject {
    public GameSettings Settings;
    public GameState State;
}