using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

public class LevelGenerator : MonoBehaviour {
    [SerializeField] private GlobalContext _context;
    [SerializeField] private GameObject _rowMarkerPrefab;

    [SerializeField] private List<Transform> _laneSpawnPoints;

    [SerializeField] private int _desiredRowCount = 20;

    [SerializeField] private float _frequencyMultiplier = .1f;
    [SerializeField] private float _minFrequencyMultiplier = .05f;
    [SerializeField] private float _maxFrequencyMultiplier = .5f;
    [SerializeField] private float _difficultySlope = 1f;
    [SerializeField] private float _initialHoleChance = 0.1f;
    [SerializeField] private float _initialValidTileChance = 0.5f;

//    [SerializeField] private GameObject _platformPrefab1;
//    [SerializeField] private GameObject _platformPrefab2;
//    [SerializeField] private GameObject _platformPrefab3_Empty;

    [SerializeField] private List<TrackPrefab> _trackPrefabs;

    [SerializeField] private float _tileSize = 1;

    private Queue<TrackTileDetails[]> _rows;

    private Transform _lastRowTransform;

    private Dictionary<TrackTile.TileType, GameObject> _trackPrefabsDictionary;


    private int _rowsGenerated;

    private int _activeRowsCount;

    private float _holeChance;
    private float _validTileChance;

    private TilePool _pool = new TilePool();

    // Start is called before the first frame update
    void Start() {
        _holeChance = _initialHoleChance;
        _validTileChance = _initialValidTileChance;
        _rows = new Queue<TrackTileDetails[]>();

        InitTrackPrefabs();

        for (int x = 0; x < 7; x++) {
            GenerateInitialRow();
        }

        for (int x = 0; x < 20; x++) {
            GenerateRow();
        }

        StartCoroutine(SpawnTile());
        InitLevel();
    }

    private void OnEnable() {
        _context.State.OnRowDestroyed += OnRowDestroyed;
    }

    private void OnDisable() {
        _context.State.OnRowDestroyed -= OnRowDestroyed;
    }

    private void OnRowDestroyed() {
        _activeRowsCount--;
    }

    private void InitTrackPrefabs() {
        _trackPrefabsDictionary = new Dictionary<TrackTile.TileType, GameObject>();
        _trackPrefabs.ForEach(t => _trackPrefabsDictionary.Add(t.TileType, t.Prefab));
    }

    private void InitLevel() {
        for (int x = 0; x < 20; x++) {
            SpawnRow(x, false);
//            foreach (var p in _laneSpawnPoints) {
//                if (Random.Range(0, 1f) < .7) {
//                    Spawn(_platformPrefab1, p.position + new Vector3(-x, 0, 0));
//                }
//            }
        }
    }

    // Update is called once per frame
    IEnumerator SpawnTile() {
        while (true) {
            if (_activeRowsCount < _desiredRowCount) {
                SpawnRow();
            }

//            _laneSpawnPoints.ForEach(p => {
//                if (Random.Range(0, 1f) < .7) {
//                    Spawn(RandomTile(), p.position);
//                }
//            });
            _holeChance = Mathf.Clamp(_holeChance + Time.deltaTime * _difficultySlope, 0, 0.7f);
            _validTileChance = Mathf.Clamp(_validTileChance - Time.deltaTime * _difficultySlope, 0.2f, 1f);
            yield return new WaitForSeconds(.25f / _context.State.GameSpeed);
        }
    }

    private GameObject SpawnTile(TrackTile.TileType type, GameObject prefab, Vector3 position) {
        var tile = _pool.Get(prefab);
        tile.Restore(position, type);
        return tile.gameObject;
//        return Instantiate(prefab, position, Quaternion.identity);
    }

    private void GenerateRow() {
//        var tileTypes = new TrackTile.TileType[_laneSpawnPoints.Count];
        var tileTypes = new TrackTileDetails[_laneSpawnPoints.Count];

        TrackTile.TileType validTile = TrackTile.TileType.Tile1;
        TrackTile.TileType invalidTile = TrackTile.TileType.Tile2;
        TrackTile.TileType emptyTile = TrackTile.TileType.Empty;

        var colorIndex = _rowsGenerated /
                         ((int) _context.State.GameSpeed * _context.Settings.General.ColorChangeInterval);

//        var holeChance = 0.5f;
//        var validTileChance = 0.5f;
        
        for (var i = 1; i < tileTypes.Length - 1; i++) {
            tileTypes[i].Type = Random.Range(0,1f) < _holeChance 
                ? emptyTile 
                : Random.Range(0,1f) > _validTileChance 
                    ? validTile 
                    : invalidTile;
            tileTypes[i].ColorIndex = colorIndex;
        }

        
        var freqShift = (Mathf.Sin(Time.time)/2 + .5f) + .5f;
        
        var sin01A = Mathf.Sin(_rowsGenerated * _frequencyMultiplier) * 0.5f + 0.5f;
        var sin01B = Mathf.Sin(1.23f + _rowsGenerated * _frequencyMultiplier*freqShift) * 0.5f + 0.5f;
        var index = Mathf.RoundToInt((sin01A * 0.6f + sin01B * 0.4f) * (_laneSpawnPoints.Count - 3 /*borders*/) + 1);
        tileTypes[index].Type = validTile;
        if (index < _laneSpawnPoints.Count - 2 && Random.Range(0,1f)<0.5f) {
            tileTypes[index+1].Type = validTile;    
        }

        tileTypes[0].Type = invalidTile;
        tileTypes[0].ColorIndex = colorIndex;
        tileTypes[tileTypes.Length - 1].Type = invalidTile;
        tileTypes[tileTypes.Length - 1].ColorIndex = colorIndex;

        _rows.Enqueue(tileTypes);
        _rowsGenerated++;
    }

//    private void GenerateRow() {
////        var tileTypes = new TrackTile.TileType[_laneSpawnPoints.Count];
//        var tileTypes = new TrackTileDetails[_laneSpawnPoints.Count];
//
//        TrackTile.TileType validTile = TrackTile.TileType.Tile1;
//        TrackTile.TileType invalidTile = TrackTile.TileType.Tile2;
//
//        var colorIndex = _rowsGenerated / ((int) _context.State.GameSpeed * _context.Settings.General.ColorChangeInterval);
//        
//        for (var i = 1; i < tileTypes.Length-1; i++) {
////            tileTypes[i].Type = validTile;
//            tileTypes[i].ColorIndex = colorIndex;
//            var random = Random.Range(0,1f);
//            if (random < 0.2) {
//                tileTypes[i].Type = TrackTile.TileType.Empty;
////                tileTypes[i] = TrackTile.TileType.Tile1;
//            } else if (random < 0.8) {
//                tileTypes[i].Type = validTile;
////                tileTypes[i] = TrackTile.TileType.Tile1;
//            }
//            else {
//                tileTypes[i].Type = invalidTile;
////                tileTypes[i] = TrackTile.TileType.Tile2;
//            }
//        }
//        tileTypes[0].Type = invalidTile;
//        tileTypes[0].ColorIndex = colorIndex;
//        tileTypes[tileTypes.Length - 1].Type = invalidTile;
//        tileTypes[tileTypes.Length - 1].ColorIndex = colorIndex;
//
//        _rows.Enqueue(tileTypes);
//        _rowsGenerated++;
//    }

    private void GenerateInitialRow() {
//        var tileTypes = new TrackTile.TileType[_laneSpawnPoints.Count];
        var tileTypes = new TrackTileDetails[_laneSpawnPoints.Count];
        for (var i = 0; i < tileTypes.Length; i++) {
            tileTypes[i].Type = TrackTile.TileType.Tile1;
        }

        _rows.Enqueue(tileTypes);
        _rowsGenerated++;
    }

    private void SpawnRow(float offset = 0, bool setInitPosition = true) {
        var row = _rows.Dequeue();

        TrackTile lastTileInRow = null;
        for (var i = 0; i < row.Length; i++) {
            var spawnPosition = _laneSpawnPoints[i].position + new Vector3(0, 0, offset);
            if (_lastRowTransform != null) {
                spawnPosition.z = _lastRowTransform.position.z + _tileSize;
            }

            lastTileInRow = SpawnTile(row[i].Type, _trackPrefabsDictionary[row[i].Type], spawnPosition).GetComponent<TrackTile>();
            lastTileInRow.SetColorByIndex(row[i].ColorIndex);
            if (setInitPosition) {
                lastTileInRow.SetInitPosition();
            }
        }

        _lastRowTransform = lastTileInRow?.transform;

        _activeRowsCount++;
        Instantiate(_rowMarkerPrefab, _lastRowTransform.position, Quaternion.identity);
        //generate new row after cosuming one
        GenerateRow();
    }

    [Serializable]
    public struct TrackPrefab {
        public TrackTile.TileType TileType;
        public GameObject Prefab;
    }

    private struct TrackTileDetails {
        public TrackTile.TileType Type;
        public int ColorIndex;
    }

    class TilePool {
        private readonly List<TrackTile> _activeTiles = new List<TrackTile>();
        private readonly List<TrackTile> _inactiveTiles = new List<TrackTile>();

        public TrackTile Get(GameObject prefab) {
            if (_inactiveTiles.Count > 0) {
                var tile = _inactiveTiles[0];
                _inactiveTiles.RemoveAt(0);
                _activeTiles.Add(tile);
                tile.gameObject.SetActive(true);
                return tile;
            }
            else {
                var tile = Instantiate(prefab).GetComponent<TrackTile>();
                tile.OnRemove += OnTileRemoved;
                _activeTiles.Add(tile);
                return tile;
            }
        }

        private void OnTileRemoved(TrackTile tile) {
            Return(tile);
        }

        public void Return(TrackTile trackTile) {
            _activeTiles.Remove(trackTile);
            trackTile.gameObject.SetActive(false);
            _inactiveTiles.Add(trackTile);
        }
        
    }
}