using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//TODO use mapped inputs (Buttons, Axes)
public class PlayerController : MonoBehaviour {
    [SerializeField] private GlobalContext _context;
    [SerializeField] private float _moveSpeed = 1;
    [SerializeField] private float _moveDistance = 1;
    [SerializeField] private float _jumpForce = 100;
    [SerializeField] private float _jumpRequestPeriod = .1f;
    [SerializeField] private Transform _groundCheck;
    [SerializeField] private BoolReference _isTakingDamage;
    [SerializeField] private FloatReference _health;
    [SerializeField] private float _damageForgivingDuration = .1f;
    [SerializeField] private float _healthRegenerationDelay = 2f;
    [SerializeField] private float _healthRegenerationRate = .2f;
    [SerializeField] private Sparks _sparks;
    [SerializeField] private bool _godMode;
    [SerializeField] private float _damageMultiplier = 1f;
    [SerializeField] private AudioSource _jumpSound;
    [SerializeField] private AudioSource _landSound;
    [SerializeField] private AudioSource _explosionSound;

    private Rigidbody _rigidbody;

//    private float _targetPositionZ;
    private float _direction;

    private bool _isGrounded;
    private float _lastJumpRequestTime;

    private TrackTile _currentTile;

    private Color _dafaultColor;
    private MeshRenderer _renderer;

    private float _damageStartTime;
    private float _damageStopTime;

    private void Awake() {
        _health.Set(1);
        _isTakingDamage.Set(false);
    }

    // Start is called before the first frame update
    void Start() {
//        _targetPositionZ = transform.position.z;
        _rigidbody = GetComponent<Rigidbody>();
        _renderer = GetComponentInChildren<MeshRenderer>();
        _dafaultColor = _renderer.material.color;
        _sparks.SetEmmiting(false);
    }

    // Update is called once per frame
    void Update() {
        if (_context.State.IsGamePaused || _context.State.IsGameOver || _context.State.IsInputDisabled) {
            return;
        }

        HandleMovement();
        GroundCheck();


        if (_currentTile != null) {
            if (_currentTile.Type == _context.State.CurrentTileToAvoid) {
                if (_damageStartTime <= 0) {
                    _damageStartTime = Time.time;   
                    _damageStopTime = -1;
                }
            }
            else {
                _damageStartTime = -1;
                _damageStopTime = Time.time;
            }
            _isTakingDamage.Set(_damageStartTime > 0 && _damageStartTime + _damageForgivingDuration < Time.time);
        }
        else {
            _damageStopTime = Time.time;
        }

        if (_isTakingDamage) {
//            _renderer.material.color = Color.white;
            _health.Set(Mathf.Clamp(_health - Time.deltaTime * _damageMultiplier, 0, 1));
            CameraShake.Instance.Shake(.3f,.1f);
            if (_health <= 0) {
                if (!_godMode){
                    _context.State.PlayerDead();
                    Destroy(gameObject);
                }
            }
        }
        else {
//            _renderer.material.color = _dafaultColor;
            if (_damageStopTime > 0 && _damageStopTime +_healthRegenerationDelay > Time.time) {
                _health.Set(Mathf.Clamp01(_health + Time.deltaTime * _healthRegenerationRate));
            }
        }
        _sparks.SetEmmiting(_isTakingDamage);


        HandleJumpInput();
        HandleJump();

        _context.State.AddScore(Time.deltaTime);

        HandleDebugRestart();

        if (Input.GetKey(KeyCode.LeftShift) && Input.GetKeyDown(KeyCode.G)) {
            _godMode = !_godMode;
        }
    }

    private void GroundCheck() {
        RaycastHit hit;
        if (Physics.Raycast(_groundCheck.position, Vector3.down, out hit, .1f)) {
            _isGrounded = true;
            _currentTile = hit.collider.gameObject.GetComponent<TrackTile>();
        }
        else {
            _isGrounded = false;
            _currentTile = null;
        }
    }

    private void HandleMovement() {
        _direction = 0;
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) {
            _direction = -1;
        }

        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) {
//            _targetPositionZ -= _moveDistance;
            _direction = 1;
        }

        transform.Translate(new Vector3(_direction, 0, 0) * Time.deltaTime * _moveSpeed);
    }

//    private void HandleMovement() {
//        _direction = 0;
//        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) {
//            _rigidbody.AddForce(new Vector3(0, 0, _moveSpeed), ForceMode.VelocityChange);
//        }
//
//        if (Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) {
//            _rigidbody.AddForce(new Vector3(0, 0, -_moveSpeed), ForceMode.VelocityChange);
//        }
//
//        _rigidbody.velocity = new Vector3(0, _rigidbody.velocity.y, Mathf.Clamp(_rigidbody.velocity.z, -2, 2)); 
//
////        transform.Translate(new Vector3(0, 0, _direction) * Time.deltaTime * _moveSpeed);
//    }

    private void HandleDebugRestart() {
        if (transform.position.y < -2) {
//            Debug.Log($"Restarting scene - player below treshold level {transform.position.y}");
//            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            _context.State.PlayerDead();
            Destroy(gameObject);
        }
    }

    private void HandleJumpInput() {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) {
            _lastJumpRequestTime = Time.time;
        }
    }

    private void HandleJump() {
        if (_isGrounded && _lastJumpRequestTime >= Time.time - _jumpRequestPeriod) {
//        if (_isGrounded && Input.GetButton("Jump")) {
            _rigidbody.AddForce(Vector3.up * _jumpForce, ForceMode.Impulse);
            _lastJumpRequestTime = 0;
            if (_jumpSound) {
                _jumpSound.PlayOneShot(_jumpSound.clip);
            }
        }
    }
}