using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sparks : MonoBehaviour {
    private ParticleSystem[] _particleSystems;

    private void Awake() {
        _particleSystems = GetComponentsInChildren<ParticleSystem>();
    }

    public void SetEmmiting(bool state) {
        foreach (var system in _particleSystems) {
            system.enableEmission = state;
        }
    }
}
