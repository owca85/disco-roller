using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "LD51/GlobalSettings",fileName = "GlobalSettings")]
public class GameSettings : ScriptableObject {

    public PlayerSettings Player;
    public ScoringSettings Scoring;
    public GeneralSettings General;
    public ColorPair[] Colors;
    
    
    [Serializable]
    public class PlayerSettings {
        public float BaseHealth = 10;
        public float StaminaUsagePerSecond = .1f;
    }
    
    [Serializable]
    public class ScoringSettings {
        public int ScorePerKill = 100;
        public int ScorePerSecond = 10;
    }
    
    [Serializable]
    public class GeneralSettings {
        public int ColorChangeInterval = 10;
    }
    
    [Serializable]
    public struct ColorPair {
        public Color Color1;
        public Color Color2;
    }
}
