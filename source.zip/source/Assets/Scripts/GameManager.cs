using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField] private GlobalContext _context;
    [SerializeField] private FloatReference _timeLeftToChangeTile;
    [SerializeField] private GameObject _musicPrefab;
    
    void Start() {
        _context.State.CurrentTileToAvoid = TrackTile.TileType.Tile2;
        _context.State.NextTileToAvoid = TrackTile.TileType.Tile1;
        _context.State.ChangeTileToAvoid();
        ResetTime();
        if (FindObjectOfType<Music>() == null) {
            Instantiate(_musicPrefab);    
        }
    }

    private void OnEnable() {
        _context.State.OnGameOver += OnGameOver;
    }
    
    private void OnDisable() {
        _context.State.OnGameOver -= OnGameOver;
    }

    private void OnGameOver() {
        Debug.Log($"GAME OVER");
//        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void Update()
    {
        if (_context.State.IsGamePaused) {
            return;
        }

        _timeLeftToChangeTile.Set(_timeLeftToChangeTile - Time.deltaTime);
        if (_timeLeftToChangeTile <= 0) {
            ResetTime();
            _context.State.ChangeTileToAvoid();
        }
    }

    private void ResetTime() {
        _timeLeftToChangeTile.Set(_context.Settings.General.ColorChangeInterval);
    }
}
