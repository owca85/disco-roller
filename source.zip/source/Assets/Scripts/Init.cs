﻿using UnityEngine;

public class Init : MonoBehaviour {
    [SerializeField] private GlobalContext _context;
//    [SerializeField] private PlayerScoreContextSO _scoreContext;

    private void Awake() {
        _context.State.Reset();
//        _scoreContext.Reset();
    }
}