using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Music : MonoBehaviour {

    private AudioSource _audio;
    
    void Start()
    {
        DontDestroyOnLoad(gameObject);
        _audio = GetComponent<AudioSource>();
    }

    private void Update() {
        if (Input.GetKeyDown(KeyCode.M)) {
            _audio.mute = !_audio.mute;
        }
    }
}
