using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RowMarker : MonoBehaviour {

    [SerializeField] private GlobalContext _context;

    void Update() {
        transform.Translate(Vector3.back * _context.State.GameSpeed * Time.deltaTime);

        if (transform.position.z < -3) {
            _context.State.RowDestroyed();
            Destroy(gameObject);
        }
    }
}
