using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using Random = UnityEngine.Random;

public class TrackTile : MonoBehaviour {
    [SerializeField] private GlobalContext _context;
    [SerializeField] private TileType _type;
    [SerializeField] private Color[] _colors;

    public event Action<TrackTile> OnRemove;
    
    private MeshRenderer _renderer;
    private MaterialPropertyBlock _materialPropertyBlock;

    private bool _isPulsing;

    private void Awake() {
        _materialPropertyBlock = new MaterialPropertyBlock();
        _isPulsing = Random.Range(0, 1f) < 0.3;
        _renderer = GetComponentInChildren<MeshRenderer>();
        _materialPropertyBlock.SetFloat("_Intensity", Random.Range(1, 6));
        _renderer.SetPropertyBlock(_materialPropertyBlock);
    }

    // Update is called once per frame
    void Update() {
        transform.Translate(Vector3.back * _context.State.GameSpeed * Time.deltaTime);

        var posY = Mathf.Lerp(transform.position.y, 0, Time.deltaTime*3);
        transform.position = new Vector3(transform.position.x, posY, transform.position.z);
        
        if (transform.position.z < -3) {
//            Destroy(gameObject);
            OnRemove?.Invoke(this);
        }

        if (_isPulsing) {
            _materialPropertyBlock.SetFloat("_Intensity", Mathf.Sin(Time.time * 10) * 4 + 5);
            _renderer.SetPropertyBlock(_materialPropertyBlock);
        }
    }

    public TileType Type => _type;

    public enum TileType {
        Empty,
        Tile1,
        Tile2
    }

    public void SetInitPosition() {
        transform.Translate(new Vector3(0,-10,0));
    }
    
    public void SetColorByIndex(int colorIndex) {
        if (_renderer) {
            var colorPair = _context.Settings.Colors[colorIndex % _context.Settings.Colors.Length];
            var color = Type == TileType.Tile1 ? colorPair.Color1 : colorPair.Color2;
            _materialPropertyBlock.SetColor("_Color", color);
            _renderer.SetPropertyBlock(_materialPropertyBlock);
        }
    }

    public void Restore(Vector3 position, TileType type) {
        transform.position = position;
        _type = type;
    }
}