using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "LD51/TrackTile",fileName = "TrackTile")]
public class TrackTileSO : ScriptableObject {

    public GameObject Prefab;
    public TrackTile.TileType Type;
    public Color Color;
}
