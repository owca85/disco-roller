using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiscoBall : MonoBehaviour {

    [SerializeField] private float _rotationSpeed;
    
    void Update() {
        transform.Rotate(Vector3.right, _rotationSpeed * Time.deltaTime);
    }
}
